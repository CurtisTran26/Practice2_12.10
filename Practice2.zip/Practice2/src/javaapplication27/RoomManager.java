
package javaapplication27;

import java.util.Scanner;

public class RoomManager {
    public static void main(String[] args) throws Exception {
        RoomList dsPhong = new RoomList();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Room");
            System.out.println("2. Remove Room");
            System.out.println("3. Update Room");
            System.out.println("4. Count by Category");
            System.out.println("5. Calculate Total Rent");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    dsPhong.addRoom();
                    break;
                case 2:
                    dsPhong.removeRoom();
                    break;
                case 3:
                    dsPhong.updateRoom();
                    break;
                case 4:
                    dsPhong.countByCategory();
                    break;
                case 5:
                    dsPhong.calculateTotalRent();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }
}

