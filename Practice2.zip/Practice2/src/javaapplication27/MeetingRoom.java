
package javaapplication27;

import java.util.Date;


public class MeetingRoom extends Room {
    private int chairCount;

    public MeetingRoom(int chairCount, String roomId, String roomCategory, Date checkInDate, Date checkOutDate, double rate) {
        super(roomId, roomCategory, checkInDate, checkOutDate, rate);
        this.chairCount = chairCount;
    }

    public MeetingRoom(int chairCount) {
        this.chairCount = chairCount;
    }

    public MeetingRoom() {
    }

    public int getChairCount() {
        return chairCount;
    }

    public void setChairCount(int chairCount) {
        this.chairCount = chairCount;
    }

    
}

