
package javaapplication27;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class RoomList {
    private List<Room> roomList;
    private Scanner sc = new Scanner(System.in);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public RoomList() {
        roomList = new ArrayList<>();
    }

   
    public void addRoom() throws Exception {
        System.out.print("Enter Room ID: ");
        String roomId = sc.nextLine();
        System.out.print("Enter Room Category (A/B/C): ");
        String roomCategory = sc.nextLine();
        System.out.print("Enter Check-in Date (dd/MM/yyyy): ");
        Date checkInDate = dateFormat.parse(sc.nextLine());
        System.out.print("Enter Check-out Date (dd/MM/yyyy): ");
        Date checkOutDate = dateFormat.parse(sc.nextLine());
        System.out.print("Room Type? (1: Bedroom, 2: Meeting Room): ");
        int roomType = sc.nextInt();
        sc.nextLine(); 

        if (roomType == 1) {
            System.out.print("Enter Bed Count: ");
            int bedCount = sc.nextInt();
            roomList.add(new BedRoom(bedCount, roomId, roomCategory, checkInDate, checkOutDate, roomType));
        } else if (roomType == 2) {
            System.out.print("Enter Chair Count: ");
            int chairCount = sc.nextInt();
            roomList.add(new MeetingRoom(chairCount, roomId, roomCategory, checkInDate, checkOutDate, roomType));
        }
    }

    public void removeRoom() {
        System.out.print("Enter Room ID to remove: ");
        String roomId = sc.nextLine();
        roomList.removeIf(room -> room.getRoomId().equals(roomId));
    }

 
    public void updateRoom() throws Exception {
        System.out.print("Enter Room ID to update: ");
        String roomId = sc.nextLine();
        System.out.print("Enter new Room Category (A/B/C): ");
        String newCategory = sc.nextLine();
        System.out.print("Enter new Check-in Date (dd/MM/yyyy): ");
        Date newCheckIn = dateFormat.parse(sc.nextLine());
        System.out.print("Enter new Check-out Date (dd/MM/yyyy): ");
        Date newCheckOut = dateFormat.parse(sc.nextLine());
        System.out.print("Room Type? (1: Bedroom, 2: Meeting Room): ");
        int roomType = sc.nextInt();
        sc.nextLine(); // Clear buffer

        for (int i = 0; i < roomList.size(); i++) {
            if (roomList.get(i).getRoomId().equals(roomId)) {
                if (roomType == 1) {
                    System.out.print("Enter new Bed Count: ");
                    int newBedCount = sc.nextInt();
                    roomList.set(i, new BedRoom(newBedCount, roomId, newCategory, newCheckIn, newCheckOut, i));
                } else if (roomType == 2) {
                    System.out.print("Enter new Chair Count: ");
                    int newChairCount = sc.nextInt();
                    roomList.set(i, new MeetingRoom(newChairCount, roomId, newCategory, newCheckIn, newCheckOut, i));
                }
                break;
            }
        }
    }

    // Count rooms by category
    public void countByCategory() {
        int countA = 0, countB = 0, countC = 0;
        for (Room room : roomList) {
            switch (room.getRoomCategory()) {
                case "A":
                    countA++;
                    break;
                case "B":
                    countB++;
                    break;
                case "C":
                    countC++;
                    break;
            }
        }
        System.out.println("Number of rooms in category A: " + countA);
        System.out.println("Number of rooms in category B: " + countB);
        System.out.println("Number of rooms in category C: " + countC);
    }

    // Calculate total rent of all rooms
    public void calculateTotalRent() {
        double totalRent = 0;
        for (Room room : roomList) {
            totalRent += room.calculateRent();
        }
        System.out.println("Total Rent of all rooms: " + totalRent);
    }
}

