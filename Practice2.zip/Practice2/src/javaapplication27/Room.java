
package javaapplication27;

import java.util.Date;

public class Room implements IRoom {
    private String roomId;
    private String roomCategory;
    private Date checkInDate;
    private Date checkOutDate;
    private double rate;

    public Room(String roomId, String roomCategory, Date checkInDate, Date checkOutDate, double rate) {
        this.roomId = roomId;
        this.roomCategory = roomCategory;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.rate = rate;
    }

    public Room() {
    }
    
    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getRoomCategory() {
        return roomCategory;
    }

    public void setRoomCategory(String roomCategory) {
        this.roomCategory = roomCategory;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    private double getRateByCategory(String roomCategory) {
        switch (roomCategory) {
            case "A":
                return 1200000;
            case "B":
                return 1000000;
            case "C":
                return 750000;
            default:
                return 0;
        }
    }

   
    private long calculateRentedDays() {
        long differenceInMillies = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
        long days = differenceInMillies / (1000 * 60 * 60 * 24);
        return days == 0 ? 1 : days;
    }

    
    @Override
    public double calculateRent() {
        return rate * calculateRentedDays();
    }


   
}

