package javaapplication27;

public interface IRoom {

    public double calculateRent();
}
