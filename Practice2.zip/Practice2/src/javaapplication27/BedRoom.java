
package javaapplication27;

import java.util.Date;

public class BedRoom extends Room {
    private int bedCount;

    public BedRoom(int bedCount, String roomId, String roomCategory, Date checkInDate, Date checkOutDate, double rate) {
        super(roomId, roomCategory, checkInDate, checkOutDate, rate);
        this.bedCount = bedCount;
    }

    public BedRoom(int bedCount) {
        this.bedCount = bedCount;
    }

    public BedRoom() {
    }

    public int getBedCount() {
        return bedCount;
    }

    public void setBedCount(int bedCount) {
        this.bedCount = bedCount;
    }

   
}
